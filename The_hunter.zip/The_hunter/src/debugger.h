#ifndef DEBUGGER_H
#define DEBUGGER_H

#include<stdio.h>
int debug(){
    printf("调试中:工作正常\n");
    return 0;
}

#endif