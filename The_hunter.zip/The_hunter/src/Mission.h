#ifndef MISSION_H
#define MISSION_H

#include "Data.h"
#include "SystemTools.h"
int get_mission()
{
    int dice=roll(2);
    //mission_number
    //working...
    
}
int mission()
{
    //执行任务
    get_mission();
}
#endif
