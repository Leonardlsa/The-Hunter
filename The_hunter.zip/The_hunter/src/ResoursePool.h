#ifndef RESOURSEPOOLS
#define RESOURSEPOOLS
//资源常量池
char rank_name[5][16]={
    "Oberleutnant",
    "Kapitanleutnant",
    "Korvettenkapitan",
    "Fregattenkapitan",
    "Kapitan_zur_See"
};

char award_name[5][40]={
    "还没有",
    "铁十字勋章",
    "橡树铁十字勋章",
    "橡树剑铁十字勋章",
    "钻石橡树剑铁十字勋章"
};

char crew_quality_name[4][8]={
    "新兵",
    "受训",
    "老鸟",
    "精锐"
};
char mission_name[9][20]=
{
    "西班牙海岸","英吉利海峡","挪威",
    "大西洋","西非海岸","地中海",
    "北美","北极","加勒比海"
};

char mission_type_name[4][20]=
{
    "布置海雷","狼群行动",
    "护送特工","水域巡航"
};


#endif